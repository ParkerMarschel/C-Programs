> Nothing is correctly working as I tried many implementations that could not provide the desired result.
I attempted SRFT-P first by trying to use the SJF function initially but ran into trouble later when going
into a blocked state I could never fix a segmentation fault that I was getting.

> I did not attempt Round Robin Scheduling as I could not get the FCFS-P or SRTF-P to work correctly.

> There are memory leaks, too many for any extra credit.

> I/O Threading is done correctly but new threading for sim04 is not implemented.
